#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "AD.h"

uint16_t Get_Battery_Voltage(void)
{
    uint16_t ADValue;
    uint16_t Voltage;

    ADValue = AD_GetValue();

    // 两个10k电阻分压，所以这里是 660，不是 330
    Voltage = ADValue * 660 / 4095;

    return Voltage;   // 单位：0.01V，例如 372 = 3.72V
}

uint8_t Get_SOC(uint16_t Voltage)
{
    if (Voltage >= 420) return 100;
    if (Voltage >= 410) return 95;
    if (Voltage >= 400) return 90;
    if (Voltage >= 392) return 80;
    if (Voltage >= 385) return 70;
    if (Voltage >= 380) return 60;
    if (Voltage >= 375) return 50;
    if (Voltage >= 370) return 40;
    if (Voltage >= 365) return 20;
    if (Voltage >= 360) return 10;
    if (Voltage >= 350) return 5;
    return 0;
}

int main(void)
{
    uint16_t Voltage;
    uint8_t SOC;

    OLED_Init();
    AD_Init();

    OLED_ShowString(1, 1, "1S Li BMS");
    OLED_ShowString(2, 1, "V:");
    OLED_ShowString(3, 1, "SOC:");
    OLED_ShowString(4, 1, "Status:");

    while (1)
    {
        Voltage = Get_Battery_Voltage();
        SOC = Get_SOC(Voltage);

        OLED_ShowNum(2, 3, Voltage / 100, 1);
        OLED_ShowString(2, 4, ".");
        OLED_ShowNum(2, 5, Voltage % 100, 2);
        OLED_ShowString(2, 7, "V");

        OLED_ShowNum(3, 5, SOC, 3);
        OLED_ShowString(3, 8, "%");

        if (Voltage >= 418)
        {
            OLED_ShowString(4, 8, "FULL");
        }
        else if (Voltage <= 320)
        {
            OLED_ShowString(4, 8, "LOW ");
        }
        else
        {
            OLED_ShowString(4, 8, "OK  ");
        }

        Delay_ms(500);
    }
}